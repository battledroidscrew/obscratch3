import React, { useState, useEffect } from 'react';
import { 
  Plus, Trash2, Edit2, CheckSquare, Square, Download, Copy, RefreshCw, 
  ExternalLink, FolderArchive, Users, Layers, CheckCircle2, AlertCircle, 
  MessageSquare, HelpCircle, Save, X, Check, Shield, FileText, Share2, ChevronDown, ChevronRight
} from 'lucide-react';

const INITIAL_THEMES = [
  "First Things First",
  "Aanbod",
  "Team",
  "Werkgroepen",
  "Infrastructuur & Veiligheid",
  "Samenwerkingen & Verhuur",
  "Juridisch & Financieel"
];

const ORGANIZATIONS = [
  { name: "Battle Droids", color: "bg-blue-600 text-white border-blue-500", badgeColor: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  { name: "Kras", color: "bg-red-600 text-white border-red-500", badgeColor: "bg-red-500/20 text-red-400 border-red-500/30" },
  { name: "Habbekrats", color: "bg-emerald-600 text-white border-emerald-500", badgeColor: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
  { name: "Allemaal", color: "bg-yellow-500 text-black border-yellow-400", badgeColor: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" }
];

const INITIAL_PERSONS = ["Camine", "Kaat", "Berten", "Jolien", "Frank", "Servaes", "Bernard", "Kobe", "Hamza", "Zakaria", "Inäs", "Lars"];

const INITIAL_ITEMS = [
  {
    id: "ftf-1",
    theme: "First Things First",
    project: "OB (vernieuwd document)",
    info: "Voorstel om het document dat we hier gebruiken een update te geven, graag feedback.",
    type: "D",
    date: "28/10/2026",
    link: "",
    status: "Op basis van feedback verder aanpassen/evalueren.",
    updates: [],
    todos: [
      { id: "t1", text: "Verder aanpassen obv feedback", done: false, org: "Kras", assignedTo: "Camine" }
    ],
    teamUpdate: "Ja"
  },
  {
    id: "ftf-2",
    theme: "First Things First",
    project: "Team Up",
    info: "Mailtje van TeamUp dat abonnementskost niet is betaald? Context: account zit op breder hab-abonnement.",
    type: "B",
    date: "28/10/2026",
    link: "",
    status: "Opgelost! Overzetten op Kras.",
    updates: [],
    todos: [
      { id: "t2", text: "Opvolgen overzetting naar Kras", done: true, org: "Kras", assignedTo: "Berten" }
    ],
    teamUpdate: "Intern"
  },
  {
    id: "ftf-3",
    theme: "First Things First",
    project: "Herfstvakantie planning",
    info: "Herfstvakantie aanpassingen staan er niet echt in. Opgelet voor overlap in gebruik ruimtes.",
    type: "M",
    date: "03/11/2026",
    link: "",
    status: "Kijkje nemen voor volgende dagen qua overlap planning.",
    updates: [],
    todos: [
      { id: "t3", text: "Whatsapp berichtje sturen over weekend", done: false, org: "Allemaal", assignedTo: "Allemaal" }
    ],
    teamUpdate: "Ja"
  },
  {
    id: "ftf-4",
    theme: "First Things First",
    project: "Poetsschema & Vuilnis",
    info: "Wat gaat er mis? Oppikken met team & poetsschema. Weekend druk bezet, rommel stapelt op.",
    type: "D",
    date: "03/11/2026",
    link: "",
    status: "Bespreken met team wat haalbaar is qua opkuis.",
    updates: [],
    todos: [
      { id: "t4", text: "OB follow up inplannen", done: false, org: "Allemaal", assignedTo: "Allemaal" }
    ],
    teamUpdate: "Ja"
  },
  {
    id: "ftf-5",
    theme: "First Things First",
    project: "AI systeem Lars",
    info: "Voorstellen AI systeem Lars, indien oké vanaf volgende OB testen?",
    type: "B",
    date: "03/11/2026",
    link: "",
    status: "Lars zet het in whatsapp met tutorial.",
    updates: [],
    todos: [
      { id: "t5", text: "Tutorial bekijken en testen", done: false, org: "Battle Droids", assignedTo: "Lars" }
    ],
    teamUpdate: "Ja"
  },
  {
    id: "aan-1",
    theme: "Aanbod",
    project: "TOKJO",
    info: "Hoe loopt het met taekwondo, meisjesgroep, en ruimtegebruik MC Lyte tot 18u30/19u?",
    type: "D",
    date: "28/10/2026",
    link: "",
    status: "Camine bevraagd Sambo wat mogelijk is en koppelt terug aan Kaat.",
    updates: [],
    todos: [
      { id: "t6", text: "Terugkoppeling Sambo & Kaat", done: false, org: "Battle Droids", assignedTo: "Camine" }
    ],
    teamUpdate: "Ja"
  },
  {
    id: "aan-2",
    theme: "Aanbod",
    project: "September evaluatie",
    info: "Uitdaging op vrijdag met veel aanbod samen. Eventueel Basquat & studio inzetten.",
    type: "M",
    date: "28/10/2026",
    link: "",
    status: "Mag uit volgende OB, enkel opvolgen als er iets naar boven komt.",
    updates: [],
    todos: [],
    teamUpdate: "Intern"
  },
  {
    id: "aan-3",
    theme: "Aanbod",
    project: "Warmste Wijk (NOVA + spektakeldag Kras)",
    info: "Wie sluit aan? Wat zijn de uren? BD sluit graag aan met Street Art.",
    type: "B",
    date: "16/12/2026",
    link: "",
    status: "Draaiboek invullen zodra Kaat het doorstuurt.",
    updates: [],
    todos: [
      { id: "t7", text: "Draaikboek invullen", done: false, org: "Kras", assignedTo: "Kaat" }
    ],
    teamUpdate: "Ja"
  },
  {
    id: "aan-4",
    theme: "Aanbod",
    project: "Kerstvakantie",
    info: "BD organiseert break kamp. Middagpauze eten in straat & spelen in village.",
    type: "D",
    date: "28/10/2026",
    link: "",
    status: "Geen Open Huis hele kerstvakantie, groepsaanbod nog te bekijken.",
    updates: [],
    todos: [
      { id: "t8", text: "Groepsaanbod kerstvakantie afstemmen", done: false, org: "Battle Droids", assignedTo: "Camine" }
    ],
    teamUpdate: "Ja"
  },
  {
    id: "tem-1",
    theme: "Team",
    project: "Team Scratch Structuur",
    info: "Zoekende naar juist moment & structuur voor Team Scratch (1x per maand of kwartaal?).",
    type: "D",
    date: "28/10/2026",
    link: "",
    status: "Voorstel: Team Scratch 1x per kwartaal als verbindend moment, praktische info via AI overlegdocumentjes.",
    updates: [],
    todos: [
      { id: "t9", text: "Flyer/info verspreiden naar team", done: false, org: "Allemaal", assignedTo: "Camine" }
    ],
    teamUpdate: "Ja"
  }
];

export default function ScratchOBApp() {
  const [themes, setThemes] = useState(INITIAL_THEMES);
  const [items, setItems] = useState(() => {
    const saved = localStorage.getItem('scratch_ob_items');
    return saved ? JSON.parse(saved) : INITIAL_ITEMS;
  });
  const [persons, setPersons] = useState(() => {
    const saved = localStorage.getItem('scratch_ob_persons');
    return saved ? JSON.parse(saved) : INITIAL_PERSONS;
  });
  const [newPersonName, setNewPersonName] = useState("");
  const [newThemeName, setNewThemeName] = useState("");
  const [showAddThemeModal, setShowAddThemeModal] = useState(false);
  const [showPersonsModal, setShowPersonsModal] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard"); // 'dashboard', 'teamup', 'archive'
  const [selectedOrgFilter, setSelectedOrgFilter] = useState("Alle");
  const [collapsedThemes, setCollapsedThemes] = useState({});
  const [archives, setArchives] = useState(() => {
    const saved = localStorage.getItem('scratch_ob_archives');
    return saved ? JSON.parse(saved) : [];
  });

  const [showItemModal, setShowItemModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formProject, setFormProject] = useState("");
  const [formTheme, setFormTheme] = useState(INITIAL_THEMES[0]);
  const [formInfo, setFormInfo] = useState("");
  const [formType, setFormType] = useState("D");
  const [formDate, setFormDate] = useState(new Date().toLocaleDateString('nl-BE'));
  const [formLink, setFormLink] = useState("");
  const [formStatus, setFormStatus] = useState("");
  const [formTeamUpdate, setFormTeamUpdate] = useState("Ja");

  const [selectedForTeamUpdate, setSelectedForTeamUpdate] = useState(
    () => items.reduce((acc, item) => ({ ...acc, [item.id]: item.teamUpdate === "Ja" }), {})
  );
  const [generatedMessage, setGeneratedMessage] = useState("");
  const [isAiRewriting, setIsAiRewriting] = useState(false);

  useEffect(() => {
    localStorage.setItem('scratch_ob_items', JSON.stringify(items));
    localStorage.setItem('scratch_ob_persons', JSON.stringify(persons));
    localStorage.setItem('scratch_ob_archives', JSON.stringify(archives));
  }, [items, persons, archives]);

  useEffect(() => {
    updateTeamMessageText();
  }, [items, selectedForTeamUpdate]);

  const updateTeamMessageText = () => {
    const activeItems = items.filter(i => selectedForTeamUpdate[i.id]);
    let text = "🚀 **SCRATCH! Team Update & Highlights** 🔥\n\nHey superhelden! Hier is een frisse en energieke update vanuit ons Operationeel Bestuur:\n\n";
    
    themes.forEach(theme => {
      const themeItems = activeItems.filter(i => i.theme === theme);
      if (themeItems.length > 0) {
        text += `📌 **${theme}**\n`;
        themeItems.forEach(item => {
          text += `• **${item.project}**: ${item.info}\n`;
          if (item.status) text += `  -> Stand van zaken: ${item.status}\n`;
        });
        text += `\n`;
      }
    });

    text += "Samen maken we er een knallende periode van! 💛🖤 Vragen of opmerkingen? Spreek ons gerust aan!";
    setGeneratedMessage(text);
  };

  const handleAiRewrite = () => {
    setIsAiRewriting(true);
    setTimeout(() => {
      setGeneratedMessage(
        "⚡ **BOOST UPDATE VANUIT SCRATCH! OB** ⚡\n\n" +
        "Briljante energie in huis! Team, we gaan als een speer. Check hieronder de belangrijkste energieboosters en acties van deze week:\n\n" +
        items.filter(i => selectedForTeamUpdate[i.id]).map(i => `💥 **${i.project}**: ${i.info} (Actie loopt!)`).join("\n") +
        "\n\nJullie zijn stuk voor stuk toppers! Let's keep rolling! 💛🖤"
      );
      setIsAiRewriting(false);
    }, 600);
  };

  const addTodo = (itemId, text, org, assignedTo) => {
    if (!text.trim()) return;
    setItems(items.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          todos: [...item.todos, { id: 't-' + Date.now(), text, done: false, org: org || "Allemaal", assignedTo: assignedTo || "Allemaal" }]
        };
      }
      return item;
    }));
  };

  const toggleTodo = (itemId, todoId) => {
    setItems(items.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          todos: item.todos.map(t => t.id === todoId ? { ...t, done: !t.done } : t)
        };
      }
      return item;
    }));
  };

  const deleteTodo = (itemId, todoId) => {
    setItems(items.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          todos: item.todos.filter(t => t.id !== todoId)
        };
      }
      return item;
    }));
  };

  const updateItemStatus = (itemId, newStatus) => {
    setItems(items.map(item => item.id === itemId ? { ...item, status: newStatus } : item));
  };

  const addStatusUpdate = (itemId, updateText) => {
    if (!updateText.trim()) return;
    const dateStr = new Date().toLocaleDateString('nl-BE');
    setItems(items.map(item => {
      if (item.id === itemId) {
        const newUpdates = [...(item.updates || []), { date: dateStr, text: updateText.trim() }];
        return { ...item, updates: newUpdates };
      }
      return item;
    }));
  };

  const toggleItemTeamUpdate = (itemId) => {
    setItems(items.map(item => {
      if (item.id === itemId) {
        const nextVal = item.teamUpdate === "Ja" ? "Intern" : "Ja";
        setSelectedForTeamUpdate(prev => ({ ...prev, [itemId]: nextVal === "Ja" }));
        return { ...item, teamUpdate: nextVal };
      }
      return item;
    }));
  };

  const addPerson = () => {
    if (newPersonName.trim() && !persons.includes(newPersonName.trim())) {
      setPersons([...persons, newPersonName.trim()]);
      setNewPersonName("");
    }
  };

  const removePerson = (p) => {
    setPersons(persons.filter(item => item !== p));
  };

  const addTheme = () => {
    if (newThemeName.trim() && !themes.includes(newThemeName.trim())) {
      setThemes([...themes, newThemeName.trim()]);
      setNewThemeName("");
      setShowAddThemeModal(false);
    }
  };

  const removeTheme = (themeToRemove) => {
    if (themes.length <= 1) {
      alert("Je moet minstens 1 thema overhouden.");
      return;
    }
    if (confirm(`Wil je thema "${themeToRemove}" en alle bijbehorende agendapunten verwijderen?`)) {
      setThemes(themes.filter(t => t !== themeToRemove));
      setItems(items.filter(i => i.theme !== themeToRemove));
    }
  };

  const openItemModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormProject(item.project);
      setFormTheme(item.theme);
      setFormInfo(item.info);
      setFormType(item.type);
      setFormDate(item.date);
      setFormLink(item.link || "");
      setFormStatus(item.status);
      setFormTeamUpdate(item.teamUpdate);
    } else {
      setEditingItem(null);
      setFormProject("");
      setFormTheme(themes[0]);
      setFormInfo("");
      setFormType("D");
      setFormDate(new Date().toLocaleDateString('nl-BE'));
      setFormLink("");
      setFormStatus("");
      setFormTeamUpdate("Ja");
    }
    setShowItemModal(true);
  };

  const saveItem = (e) => {
    e.preventDefault();
    if (!formProject.trim()) return;

    if (editingItem) {
      setItems(items.map(i => i.id === editingItem.id ? {
        ...i,
        project: formProject,
        theme: formTheme,
        info: formInfo,
        type: formType,
        date: formDate,
        link: formLink,
        status: formStatus,
        teamUpdate: formTeamUpdate
      } : i));
    } else {
      const newItem = {
        id: 'item-' + Date.now(),
        theme: formTheme,
        project: formProject,
        info: formInfo,
        type: formType,
        date: formDate,
        link: formLink,
        status: formStatus,
        updates: [],
        todos: [],
        teamUpdate: formTeamUpdate
      };
      setItems([...items, newItem]);
      setSelectedForTeamUpdate(prev => ({ ...prev, [newItem.id]: formTeamUpdate === "Ja" }));
    }
    setShowItemModal(false);
  };

  const deleteItem = (id) => {
    if (confirm("Ben je zeker dat je dit agendapunt wilt verwijderen?")) {
      setItems(items.filter(i => i.id !== id));
    }
  };

  const toggleThemeCollapse = (theme) => {
    setCollapsedThemes(prev => ({ ...prev, [theme]: !prev[theme] }));
  };

  const downloadSpreadsheet = () => {
    let csvContent = "data:text/csv;charset=utf-8,Thema,Project / Onderwerp,Info/Vraag,Type,Datum,Link,Status OB,To-Do's,Team-Update\n";
    items.forEach(item => {
      const todosStr = item.todos.map(t => `[${t.org} - ${t.assignedTo}] ${t.text} (${t.done ? 'Klaar' : 'Open'})`).join(" | ");
      const row = [
        `"${item.theme}"`,
        `"${item.project}"`,
        `"${item.info.replace(/"/g, '""')}"`,
        `"${item.type}"`,
        `"${item.date}"`,
        `"${item.link}"`,
        `"${item.status.replace(/"/g, '""')}"`,
        `"${todosStr.replace(/"/g, '""')}"`,
        `"${item.teamUpdate}"`
      ].join(",");
      csvContent += row + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `SCRATCH_OB_Overzicht_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const finalizeAndDownloadOB = () => {
    createArchiveSnapshot();
    downloadSpreadsheet();
    alert("Operationeel Bestuur succesvol afgerond! Snapshot is opgeslagen in het archief en de spreadsheet is gedownload.");
  };

  const createArchiveSnapshot = () => {
    const snapshot = {
      id: 'arch-' + Date.now(),
      date: new Date().toLocaleString('nl-BE'),
      title: `OB Snapshot (${items.length} punten)`,
      itemsCount: items.length,
      itemsData: items
    };
    setArchives([snapshot, ...archives]);
  };

  const deleteSnapshot = (archId) => {
    if (confirm("Wil je deze OB snapshot verwijderen uit het archief?")) {
      setArchives(archives.filter(a => a.id !== archId));
    }
  };

  const restoreSnapshot = (arch) => {
    if (confirm(`Wil je de staat van "${arch.title}" (${arch.date}) herstellen?`)) {
      setItems(arch.itemsData);
      alert("Snapshot succesvol hersteld!");
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-yellow-400 selection:text-black">
      
      {/* HEADER MET EXACT SCRATCH! LOGO */}
      <header className="bg-neutral-900 border-b border-yellow-500/30 px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4 sticky top-0 z-40 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-yellow-400 flex items-center justify-center p-1 shadow-inner border-2 border-yellow-500 relative overflow-hidden group shrink-0">
            <div className="absolute inset-0 bg-yellow-400 flex flex-col items-center justify-center font-black text-black leading-none">
              <span className="text-[10px] tracking-widest font-extrabold">SCR</span>
              <span className="text-[14px] font-black tracking-tighter">ACH!</span>
            </div>
            <div className="absolute bottom-0 w-full h-2 bg-black opacity-10"></div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black tracking-wider text-yellow-400">SCRATCH!</h1>
              <span className="bg-yellow-400 text-black text-xs font-black px-2 py-0.5 rounded-full uppercase">OB Hub</span>
            </div>
            <p className="text-xs text-neutral-400">Operationeel Bestuur & Communicatiedoorstroom • Antwerpen (Kras, Battle Droids, Habbekrats)</p>
          </div>
        </div>

        {/* Navigatie Tabs */}
        <div className="flex items-center gap-2 bg-neutral-950 p-1.5 rounded-xl border border-neutral-800">
          <button 
            onClick={() => setActiveTab("dashboard")}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'dashboard' ? 'bg-yellow-400 text-black shadow-md' : 'text-neutral-400 hover:text-white'}`}
          >
            <Layers className="w-4 h-4" /> Operationeel Bestuur overzicht
          </button>
          <button 
            onClick={() => setActiveTab("teamup")}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'teamup' ? 'bg-yellow-400 text-black shadow-md' : 'text-neutral-400 hover:text-white'}`}
          >
            <Share2 className="w-4 h-4" /> Team-Update Generator
          </button>
          <button 
            onClick={() => setActiveTab("archive")}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'archive' ? 'bg-yellow-400 text-black shadow-md' : 'text-neutral-400 hover:text-white'}`}
          >
            <FolderArchive className="w-4 h-4" /> Drive & Archief
          </button>
        </div>

        {/* Snelle actie knop */}
        <div className="flex items-center gap-2 flex-wrap justify-end">
          <button 
            onClick={() => setShowPersonsModal(true)}
            className="bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 font-bold px-3 py-2.5 rounded-xl flex items-center gap-1.5 text-xs transition-colors"
          >
            <Users className="w-4 h-4 text-yellow-400" /> Teamleden ({persons.length})
          </button>
          <button 
            onClick={() => openItemModal()}
            className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2 transition-transform active:scale-95 text-sm"
          >
            <Plus className="w-5 h-5 stroke-[3]" /> Nieuw Agendapunt
          </button>
        </div>
      </header>

      {/* HOOFDINHOUD */}
      <main className="flex-1 p-6 max-w-[1600px] w-full mx-auto">

        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            
            {/* Actie boven balk: Organisatie filter & Thema toevoegen */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-neutral-900/90 p-4 rounded-2xl border border-neutral-800">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Filter op organisatie:</span>
                <button
                  onClick={() => setSelectedOrgFilter("Alle")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${selectedOrgFilter === 'Alle' ? 'bg-yellow-400 text-black shadow' : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'}`}
                >
                  Alle ({items.reduce((acc, i) => acc + i.todos.length, 0)})
                </button>
                {ORGANIZATIONS.map(org => {
                  const count = items.reduce((acc, i) => acc + i.todos.filter(t => t.org === org.name).length, 0);
                  return (
                    <button
                      key={org.name}
                      onClick={() => setSelectedOrgFilter(org.name)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                        selectedOrgFilter === org.name ? `${org.color} shadow-md` : 'bg-neutral-800/80 text-neutral-300 border-neutral-700 hover:bg-neutral-700'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${org.name === 'Battle Droids' ? 'bg-blue-400' : org.name === 'Kras' ? 'bg-red-400' : org.name === 'Habbekrats' ? 'bg-emerald-400' : 'bg-yellow-400'}`}></span>
                      {org.name} ({count})
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAddThemeModal(true)}
                  className="bg-neutral-800 hover:bg-neutral-700 text-yellow-400 border border-yellow-500/30 px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Plus className="w-4 h-4" /> Thema Toevoegen
                </button>
                <button
                  onClick={finalizeAndDownloadOB}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-md transition-colors"
                >
                  <Download className="w-4 h-4" /> OB Afronden & Download (.xls)
                </button>
              </div>
            </div>

            {/* ALLE THEMA'S OPEN ONDER ELKAAR ALS DROPDOWN SECTIES */}
            <div className="space-y-6">
              {themes.map(theme => {
                const themeItems = items.filter(i => i.theme === theme);
                // Als er gefilterd is op organisatie, filter punten waarvan minstens 1 to-do bij die org hoort (of als Alle)
                const displayedItems = selectedOrgFilter === 'Alle' 
                  ? themeItems 
                  : themeItems.filter(i => i.todos.some(t => t.org === selectedOrgFilter));

                const isCollapsed = !!collapsedThemes[theme];

                return (
                  <div key={theme} className="bg-neutral-900 rounded-2xl border border-neutral-800 overflow-hidden shadow-xl">
                    
                    {/* Rode / Thema Kop */}
                    <div 
                      onClick={() => toggleThemeCollapse(theme)}
                      className="bg-[#CC0000] text-white px-6 py-3.5 flex items-center justify-between cursor-pointer hover:bg-red-700 transition-colors select-none"
                    >
                      <div className="flex items-center gap-3">
                        <span className="p-1 rounded bg-black/20 text-white">
                          {isCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                        </span>
                        <h2 className="text-base font-black tracking-wide uppercase">{theme}</h2>
                        <span className="text-xs bg-black/30 px-2.5 py-0.5 rounded-full font-bold">
                          {displayedItems.length} {displayedItems.length === 1 ? 'punt' : 'punten'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {themes.length > 1 && (
                          <button 
                            onClick={(e) => { e.stopPropagation(); removeTheme(theme); }}
                            className="text-white/70 hover:text-white p-1 rounded hover:bg-black/20 transition-colors"
                            title="Verwijder thema"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {!isCollapsed && (
                      <div className="p-4 space-y-4 bg-neutral-900/50">
                        {displayedItems.length === 0 ? (
                          <div className="text-center py-8 text-neutral-500 text-xs italic">
                            Geen agendapunten in dit thema {selectedOrgFilter !== 'Alle' ? `voor organisatie "${selectedOrgFilter}"` : ''}.
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {displayedItems.map((item, idx) => {
                              const typeColor = item.type === 'D' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                                                item.type === 'B' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' : 
                                                'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
                              const typeLabel = item.type === 'D' ? 'Dialoog' : item.type === 'B' ? 'Beslissen' : 'Mededelen';

                              return (
                                <div key={item.id} className="bg-neutral-950 rounded-xl border border-neutral-800/80 p-5 shadow-lg relative group">
                                  
                                  {/* Nummer badge */}
                                  <div className="absolute -top-2.5 left-4 bg-neutral-800 text-yellow-400 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-neutral-700">
                                    #{idx + 1}
                                  </div>

                                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start pt-2">
                                    
                                    {/* KOLOM 1 (span-3): Project & Info */}
                                    <div className="lg:col-span-3 space-y-2 border-b lg:border-b-0 lg:border-r border-neutral-800/80 pb-4 lg:pb-0 lg:pr-4">
                                      <div className="flex items-start justify-between gap-2">
                                        <h3 className="font-bold text-white text-base leading-snug">{item.project}</h3>
                                        <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                                          <button 
                                            onClick={() => openItemModal(item)}
                                            className="p-1 hover:bg-neutral-800 text-neutral-400 hover:text-white rounded"
                                            title="Bewerken"
                                          >
                                            <Edit2 className="w-3.5 h-3.5" />
                                          </button>
                                          <button 
                                            onClick={() => deleteItem(item.id)}
                                            className="p-1 hover:bg-neutral-800 text-neutral-400 hover:text-red-400 rounded"
                                            title="Verwijderen"
                                          >
                                            <Trash2 className="w-3.5 h-3.5" />
                                          </button>
                                        </div>
                                      </div>

                                      <p className="text-xs text-neutral-300 leading-relaxed">{item.info}</p>

                                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                                        <span className={`text-[10px] font-black px-2 py-0.5 rounded border ${typeColor}`} title={typeLabel}>
                                          {item.type} = {typeLabel}
                                        </span>
                                        <span className="text-[10px] bg-neutral-900 text-neutral-400 px-2 py-0.5 rounded border border-neutral-800">
                                          {item.date}
                                        </span>
                                        {item.link && (
                                          <a 
                                            href={item.link} 
                                            target="_blank" 
                                            rel="noopener noreferrer"
                                            className="text-[10px] bg-yellow-400/10 text-yellow-400 hover:bg-yellow-400/20 px-2 py-0.5 rounded border border-yellow-500/30 flex items-center gap-1 font-bold"
                                          >
                                            <ExternalLink className="w-3 h-3" /> Link
                                          </a>
                                        )}
                                      </div>
                                    </div>

                                    {/* KOLOM 2 (span-4): Status & OB Bespreking met Update-vakje eronder */}
                                    <div className="lg:col-span-4 space-y-3 border-b lg:border-b-0 lg:border-r border-neutral-800/80 pb-4 lg:pb-0 lg:pr-4">
                                      <div className="space-y-1.5">
                                        <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-wider">Huidige Status & Bespreking:</label>
                                        <textarea 
                                          rows={2}
                                          value={item.status}
                                          onChange={(e) => updateItemStatus(item.id, e.target.value)}
                                          placeholder="Status OB..."
                                          className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-2.5 text-xs text-neutral-200 focus:outline-none focus:border-yellow-400 resize-none shadow-inner"
                                        />
                                      </div>

                                      {/* Opgeslagen status updates geschiedenis */}
                                      {item.updates && item.updates.length > 0 && (
                                        <div className="space-y-1.5 bg-neutral-900/60 p-2.5 rounded-xl border border-neutral-800">
                                          <span className="text-[10px] font-bold text-neutral-400">Vorige updates:</span>
                                          {item.updates.map((up, i) => (
                                            <div key={i} className="text-[11px] text-neutral-300 border-l-2 border-yellow-400 pl-2 py-0.5">
                                              <span className="text-[10px] text-yellow-400 font-bold mr-1.5">[{up.date}]</span> {up.text}
                                            </div>
                                          ))}
                                        </div>
                                      )}

                                      {/* Vakje om status een update te geven */}
                                      <StatusUpdateInput onAddUpdate={(txt) => addStatusUpdate(item.id, txt)} />
                                    </div>

                                    {/* KOLOM 3 (span-4): To-Do's met Organisatie-kleur en Teamlid */}
                                    <div className="lg:col-span-4 space-y-3 border-b lg:border-b-0 lg:border-r border-neutral-800/80 pb-4 lg:pb-0 lg:pr-4">
                                      <label className="block text-[10px] font-black text-neutral-400 uppercase tracking-wider">To-Do's & Toewijzing:</label>
                                      
                                      <div className="space-y-2">
                                        {item.todos.map(todo => {
                                          const orgObj = ORGANIZATIONS.find(o => o.name === todo.org) || ORGANIZATIONS[3];
                                          return (
                                            <div key={todo.id} className="flex items-center justify-between gap-2 bg-neutral-900 p-2.5 rounded-xl border border-neutral-800 group/todo">
                                              <div className="flex items-center gap-2.5 overflow-hidden">
                                                <button onClick={() => toggleTodo(item.id, todo.id)} className="text-yellow-400 hover:scale-110 transition-transform shrink-0">
                                                  {todo.done ? <CheckSquare className="w-4 h-4 text-emerald-400" /> : <Square className="w-4 h-4 text-neutral-500" />}
                                                </button>
                                                <span className={`text-xs truncate ${todo.done ? 'line-through text-neutral-500' : 'text-neutral-200'}`}>
                                                  {todo.text}
                                                </span>
                                              </div>
                                              <div className="flex items-center gap-1.5 shrink-0">
                                                <span className={`text-[10px] px-2 py-0.5 rounded font-bold border ${orgObj.badgeColor}`}>
                                                  {todo.org}
                                                </span>
                                                <span className="text-[10px] bg-neutral-800 text-yellow-400 px-2 py-0.5 rounded border border-neutral-700">
                                                  {todo.assignedTo}
                                                </span>
                                                <button onClick={() => deleteTodo(item.id, todo.id)} className="text-neutral-500 hover:text-red-400 opacity-0 group-hover/todo:opacity-100 transition-opacity">
                                                  <Trash2 className="w-3 h-3" />
                                                </button>
                                              </div>
                                            </div>
                                          );
                                        })}
                                      </div>

                                      <ToDoInputForm onAdd={(text, org, assignedTo) => addTodo(item.id, text, org, assignedTo)} persons={persons} />
                                    </div>

                                    {/* KOLOM 4 (span-1): Meenemen naar Team */}
                                    <div className="lg:col-span-1 flex flex-col items-center justify-center pt-2">
                                      <button 
                                        onClick={() => toggleItemTeamUpdate(item.id)}
                                        className={`w-full py-2.5 px-1 rounded-xl text-xs font-black transition-all border flex flex-col items-center gap-1 ${
                                          item.teamUpdate === 'Ja' 
                                            ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow' 
                                            : 'bg-neutral-900 text-neutral-500 border-neutral-800'
                                        }`}
                                        title="Klik om te wisselen tussen Ja / Intern"
                                      >
                                        <span className="text-[9px] tracking-wider uppercase">Team</span>
                                        <span className="text-xs font-black">{item.teamUpdate}</span>
                                      </button>
                                    </div>

                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}

                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* TEAM-UPDATE GENERATOR TABBLAD */}
        {activeTab === 'teamup' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-5 bg-neutral-900 rounded-2xl border border-neutral-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
                <div>
                  <h2 className="text-lg font-black text-yellow-400">1. Selecteer OB Punten</h2>
                  <p className="text-xs text-neutral-400">Vink aan wat mee mag naar het bredere team.</p>
                </div>
                <span className="bg-yellow-400/10 text-yellow-400 border border-yellow-500/30 text-xs font-bold px-3 py-1 rounded-lg">
                  {Object.values(selectedForTeamUpdate).filter(Boolean).length} geselecteerd
                </span>
              </div>

              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                {items.map(item => (
                  <div 
                    key={item.id} 
                    onClick={() => setSelectedForTeamUpdate(prev => ({ ...prev, [item.id]: !prev[item.id] }))}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                      selectedForTeamUpdate[item.id] 
                        ? 'bg-neutral-800/80 border-yellow-400/50 shadow-md' 
                        : 'bg-neutral-950/40 border-neutral-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <input 
                      type="checkbox" 
                      checked={!!selectedForTeamUpdate[item.id]} 
                      onChange={() => {}} 
                      className="mt-1 w-4 h-4 accent-yellow-400 rounded cursor-pointer"
                    />
                    <div className="flex-1 overflow-hidden">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-yellow-400">{item.theme}</span>
                        <span className="text-[10px] text-neutral-500">{item.date}</span>
                      </div>
                      <h4 className="font-bold text-white text-sm truncate">{item.project}</h4>
                      <p className="text-xs text-neutral-300 line-clamp-1">{item.info}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-7 bg-neutral-900 rounded-2xl border border-neutral-800 p-6 space-y-6 shadow-xl flex flex-col">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
                <div>
                  <h2 className="text-lg font-black text-yellow-400">2. Gegenereerd Team-Bericht</h2>
                  <p className="text-xs text-neutral-400">Volledig handmatig aanpasbaar voor Whatsapp, Mail of Slack.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={handleAiRewrite}
                    disabled={isAiRewriting}
                    className="bg-yellow-400/10 hover:bg-yellow-400/20 text-yellow-400 border border-yellow-500/30 px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isAiRewriting ? 'animate-spin' : ''}`} /> Maak Positief & Motiverend
                  </button>
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(generatedMessage);
                      alert("Bericht gekopieerd naar klembord!");
                    }}
                    className="bg-yellow-400 hover:bg-yellow-300 text-black px-4 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-md transition-transform active:scale-95"
                  >
                    <Copy className="w-3.5 h-3.5" /> Kopieer Bericht
                  </button>
                </div>
              </div>

              <div className="flex-1 flex flex-col">
                <textarea 
                  rows={15}
                  value={generatedMessage}
                  onChange={(e) => setGeneratedMessage(e.target.value)}
                  className="w-full flex-1 bg-neutral-950 border border-neutral-800 rounded-xl p-4 text-sm text-neutral-200 focus:outline-none focus:border-yellow-400 font-mono resize-none leading-relaxed shadow-inner"
                />
              </div>

              <div className="bg-neutral-950/60 p-4 rounded-xl border border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Klaar om direct te delen met alle medewerkers van Kras, Battle Droids en Habbekrats!
                </span>
                <span className="font-bold text-yellow-400">SCRATCH! Communicatie</span>
              </div>
            </div>
          </div>
        )}

        {/* DRIVE & ARCHIEF TABBLAD */}
        {activeTab === 'archive' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="bg-neutral-900 rounded-2xl border border-neutral-800 p-8 space-y-6 shadow-xl">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
                <div>
                  <h2 className="text-xl font-black text-yellow-400 flex items-center gap-2">
                    <Download className="w-6 h-6" /> Google Drive & Archief Hub
                  </h2>
                  <p className="text-xs text-neutral-400 mt-1">Download de officiële spreadsheet of beheer OB snapshots.</p>
                </div>
                <button 
                  onClick={downloadSpreadsheet}
                  className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-5 py-3 rounded-xl shadow-lg flex items-center gap-2 transition-transform active:scale-95 text-sm"
                >
                  <Download className="w-4 h-4 stroke-[3]" /> Download OB Spreadsheet (.xls / .csv)
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                <div className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-4">
                  <h3 className="font-bold text-white text-base flex items-center gap-2">
                    <FolderArchive className="w-5 h-5 text-yellow-400" /> OB Snapshot Archief
                  </h3>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Sla op elk moment een snapshot op van de huidige agendapunten en besluiten of herstel een eerdere versie.
                  </p>
                  <button 
                    onClick={createArchiveSnapshot}
                    className="w-full bg-neutral-800 hover:bg-neutral-700 text-yellow-400 border border-yellow-500/30 font-bold py-2.5 rounded-xl text-xs transition-colors"
                  >
                    Snapshot Opslaan van Huidige Staat
                  </button>
                </div>

                <div className="bg-neutral-950 p-6 rounded-2xl border border-neutral-800 space-y-4">
                  <h3 className="font-bold text-white text-base flex items-center gap-2">
                    <Shield className="w-5 h-5 text-yellow-400" /> Google Drive Koppeling
                  </h3>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    Alle bestanden en mappen van SCRATCH! Operationeel Bestuur worden beheerd via de gedeelde Google Drive.
                  </p>
                  <a 
                    href="https://drive.google.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full bg-yellow-400/10 hover:bg-yellow-400/20 text-yellow-400 border border-yellow-500/30 font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-colors inline-flex"
                  >
                    Open Google Drive Map <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              <div className="space-y-3 pt-4">
                <h4 className="font-bold text-sm text-neutral-300">Opgeslagen Snapshots ({archives.length})</h4>
                {archives.length === 0 ? (
                  <p className="text-xs text-neutral-500 italic">Nog geen snapshots opgeslagen.</p>
                ) : (
                  <div className="space-y-2">
                    {archives.map(arch => (
                      <div key={arch.id} className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex items-center justify-between gap-4">
                        <div>
                          <span className="font-bold text-white text-sm">{arch.title}</span>
                          <p className="text-[10px] text-neutral-500">{arch.date}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => restoreSnapshot(arch)}
                            className="text-xs bg-neutral-800 hover:bg-neutral-700 text-yellow-400 px-3 py-1.5 rounded-lg font-bold"
                          >
                            Herstellen
                          </button>
                          <button 
                            onClick={() => deleteSnapshot(arch.id)}
                            className="text-xs bg-red-500/20 hover:bg-red-500/30 text-red-400 px-3 py-1.5 rounded-lg font-bold"
                          >
                            Verwijderen
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

      </main>

      {/* MODAL: NIEUW / BEWERK AGENDAPUNT */}
      {showItemModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-xl w-full p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <h3 className="text-lg font-black text-yellow-400">
                {editingItem ? 'Agendapunt Bewerken' : 'Nieuw OB Agendapunt'}
              </h3>
              <button onClick={() => setShowItemModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={saveItem} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-400 mb-1">Thema</label>
                  <select 
                    value={formTheme}
                    onChange={(e) => setFormTheme(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                  >
                    {themes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-neutral-400 mb-1">Type</label>
                  <select 
                    value={formType}
                    onChange={(e) => setFormType(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                  >
                    <option value="D">D = Dialoog</option>
                    <option value="B">B = Beslissen</option>
                    <option value="M">M = Mededelen</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-400 mb-1">Project / Onderwerp</label>
                <input 
                  type="text"
                  required
                  placeholder="Bijv. Tokjo, Team Up, Herfstvakantie..."
                  value={formProject}
                  onChange={(e) => setFormProject(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-400 mb-1">Korte Info / Vraag (1 zin)</label>
                <input 
                  type="text"
                  placeholder="Korte duidelijke beschrijving..."
                  value={formInfo}
                  onChange={(e) => setFormInfo(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-neutral-400 mb-1">Datum</label>
                  <input 
                    type="text"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-neutral-400 mb-1">Google Drive / Weblink (optioneel)</label>
                  <input 
                    type="url"
                    placeholder="https://..."
                    value={formLink}
                    onChange={(e) => setFormLink(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-400 mb-1">Status & Bespreking op OB</label>
                <textarea 
                  rows={2}
                  placeholder="Notities van verdere uitleg of bespreking..."
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-400 mb-1">Meenemen naar Team-Update</label>
                <select 
                  value={formTeamUpdate}
                  onChange={(e) => setFormTeamUpdate(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                >
                  <option value="Ja">Ja</option>
                  <option value="Intern">Intern</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-800">
                <button 
                  type="button" 
                  onClick={() => setShowItemModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-neutral-400 hover:text-white"
                >
                  Annuleren
                </button>
                <button 
                  type="submit"
                  className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-6 py-2.5 rounded-xl shadow-lg text-xs"
                >
                  {editingItem ? 'Opslaan' : 'Toevoegen'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: NIEUW THEMA */}
      {showAddThemeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-md w-full p-6 space-y-6 shadow-2xl">
            <h3 className="text-lg font-black text-yellow-400">Nieuw Thema Toevoegen</h3>
            <input 
              type="text"
              placeholder="Themanaam..."
              value={newThemeName}
              onChange={(e) => setNewThemeName(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
            />
            <div className="flex items-center justify-end gap-3">
              <button onClick={() => setShowAddThemeModal(false)} className="px-4 py-2 text-xs font-bold text-neutral-400">Annuleren</button>
              <button onClick={addTheme} className="bg-yellow-400 text-black font-black px-5 py-2 rounded-xl text-xs">Toevoegen</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: TEAMLEDEN BEHEREN */}
      {showPersonsModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-md w-full p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <h3 className="text-lg font-black text-yellow-400">Teamleden Beheren</h3>
              <button onClick={() => setShowPersonsModal(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <input 
                  type="text"
                  placeholder="Naam nieuw teamlid..."
                  value={newPersonName}
                  onChange={(e) => setNewPersonName(e.target.value)}
                  className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-yellow-400"
                />
                <button 
                  onClick={addPerson}
                  className="bg-yellow-400 hover:bg-yellow-300 text-black font-black px-4 py-3 rounded-xl text-xs shrink-0"
                >
                  Toevoegen
                </button>
              </div>

              <div className="max-h-60 overflow-y-auto space-y-2 pt-2">
                {persons.map(p => (
                  <div key={p} className="flex items-center justify-between bg-neutral-950 px-4 py-2.5 rounded-xl border border-neutral-800">
                    <span className="text-xs font-bold text-white">{p}</span>
                    <button onClick={() => removePerson(p)} className="text-neutral-500 hover:text-red-400 text-xs font-bold">
                      Verwijderen
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end pt-4 border-t border-neutral-800">
              <button onClick={() => setShowPersonsModal(false)} className="bg-yellow-400 text-black font-black px-6 py-2 rounded-xl text-xs">
                Klaar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

function StatusUpdateInput({ onAddUpdate }) {
  const [text, setText] = useState("");
  const handleAdd = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    onAddUpdate(text);
    setText("");
  };
  return (
    <form onSubmit={handleAdd} className="flex items-center gap-2 pt-1">
      <input 
        type="text"
        placeholder="+ Update toevoegen..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="flex-1 bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-yellow-400"
      />
      <button type="submit" className="bg-neutral-800 hover:bg-neutral-700 text-yellow-400 px-3 py-1.5 rounded-lg text-xs font-bold shrink-0">
        Voeg toe
      </button>
    </form>
  );
}

function ToDoInputForm({ onAdd, persons }) {
  const [text, setText] = useState("");
  const [org, setOrg] = useState("Allemaal");
  const [assigned, setAssigned] = useState("Allemaal");
  const [showMenu, setShowMenu] = useState(false);

  const handleAdd = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    onAdd(text, org, assigned);
    setText("");
  };

  return (
    <form onSubmit={handleAdd} className="space-y-2 pt-1">
      <div className="flex items-center gap-2">
        <input 
          type="text"
          placeholder="Nieuw actiepunt..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="flex-1 bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-yellow-400"
        />
        <button 
          type="submit"
          className="bg-yellow-400 hover:bg-yellow-300 text-black px-3 py-1.5 rounded-lg text-xs font-black shrink-0"
        >
          + Actie
        </button>
      </div>

      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <span className="text-[10px] text-neutral-400">Org:</span>
          <select 
            value={org}
            onChange={(e) => setOrg(e.target.value)}
            className="bg-neutral-900 border border-neutral-800 rounded text-[10px] text-white px-2 py-1 focus:outline-none focus:border-yellow-400"
          >
            <option value="Battle Droids">Battle Droids</option>
            <option value="Kras">Kras</option>
            <option value="Habbekrats">Habbekrats</option>
            <option value="Allemaal">Allemaal</option>
          </select>
        </div>

        <div className="flex items-center gap-1">
          <span className="text-[10px] text-neutral-400">Persoon:</span>
          <select 
            value={assigned}
            onChange={(e) => setAssigned(e.target.value)}
            className="bg-neutral-900 border border-neutral-800 rounded text-[10px] text-white px-2 py-1 focus:outline-none focus:border-yellow-400 max-w-[120px]"
          >
            <option value="Allemaal">Allemaal</option>
            {persons.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
      </div>
    </form>
  );
}
